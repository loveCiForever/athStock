# Note:
1. If you face this error: `Could not find a declaration file for module 'jsonwebtoken'` --> run `npm install -D @types/module-name`
2. 

